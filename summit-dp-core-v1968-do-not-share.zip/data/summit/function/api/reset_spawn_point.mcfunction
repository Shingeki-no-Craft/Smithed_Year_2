execute if entity @s[type=!player] run return 0
execute in minecraft:overworld run spawnpoint @s 0 225 0
