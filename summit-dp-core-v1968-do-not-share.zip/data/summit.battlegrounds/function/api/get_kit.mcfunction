
# get player data for macro
function summit.battlegrounds:utility/get_head
return run function summit.battlegrounds:utility/get_kit with storage summit.battlegrounds:temp profile
