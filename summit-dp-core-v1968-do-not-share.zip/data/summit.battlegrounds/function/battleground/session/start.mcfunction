
# reset structure
$function $(struct_function)

# clear kits
function summit.battlegrounds:utility/clear_kits with storage summit.battlegrounds:database session

# function tag
function #summit.battlegrounds:api/booth_active
