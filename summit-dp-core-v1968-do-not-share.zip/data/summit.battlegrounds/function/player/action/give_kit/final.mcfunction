
# reset timer and give kit
function summit.inventory_management:save
scoreboard players set @s summit.battlegrounds.kit_expiration 180
$function $(kit_function)
