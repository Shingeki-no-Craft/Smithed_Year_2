#> minecraft:tick

# ===========================
# ====== Join Handling ======
# ===========================

# First join based on time played scoreboard
execute as @a[scores={summit.time_played=..1}] at @s run function summit:join_detection/first_join

# Detect player joining on two conditions:
# 
# 1. If `on_join` score increments, that means they left the game
# 2. If `on_join` score doesn't exist, that means we've reloaded (occurs on server crash too!)
execute as @a unless score @s summit.on_join = @s summit.on_join run scoreboard players add @s summit.on_join 1

# On new joins..
execute as @a[scores={summit.on_join=1..}] at @s run function summit:join_detection/on_join

# ===========================
# ======= TP Triggers =======
# ===========================
scoreboard players enable @a unstuck
execute as @a[scores={unstuck=1..}] at @s run function summit:triggers/unstuck
# scoreboard players enable @a hub
# execute as @a[scores={hub=1..}] at @s run function summit:triggers/hub



# On interacting with the sticker book
execute as @a[scores={summit.sticker_book_actions=1..}] at @s run function summit.sticker_book:actions/main

# On opening the sticker book
execute as @a[scores={summit.use_book=1..}] at @s run function summit.sticker_book:open



# TODO: remove this later probably
gamerule log_admin_commands true
