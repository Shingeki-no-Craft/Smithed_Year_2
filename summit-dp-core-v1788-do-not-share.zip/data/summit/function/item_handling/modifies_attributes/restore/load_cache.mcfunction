# @s = player
# at undefined
# run by summit:item_handling/modifies_attributes/restore_all

$data modify storage summit:temp player_items.cache set from storage summit:player_items cache."$(UUID)"
