# @s = player
# at undefined
# run by summit:item_handling/modifies_attributes/restore_all
