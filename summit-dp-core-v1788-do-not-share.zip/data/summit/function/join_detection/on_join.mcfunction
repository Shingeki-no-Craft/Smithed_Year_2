#> On Join Handling
# as/at @s = player who joined
# run from summit:tick

scoreboard players set @s summit.on_join 0

# reset booth enter exit advancements
advancement revoke @s from summit:booth_hooks_root

# REMOVED ON_JOIN API TAG, NO REASON FOR BOOTH VENDORS TO HAVE THAT TBH
function #summit:api/reset_player
