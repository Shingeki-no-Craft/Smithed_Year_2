# @s = player
# at undefined
# run by player

# Arguments
# raise_height: The amount of height that the flag can move up and down (in blocks)
# wind_sync: Whether the flag should point in the same direction as other flags (boolean string)

# calculate variables
$data modify storage summit:temp summit_flag_macro set value {raise_height:$(raise_height), wind_sync:$(wind_sync), state:0}

# kill existing flag within 1 block to prevent duplicates
execute as @n[tag=aj.summit_flag.root, tag=!aj.new, distance=..1] run function animated_java:summit_flag/remove/this

# spawn aj rig and modify
execute align xyz positioned ~0.5 ~0.25 ~0.5 rotated 0 0 run function animated_java:summit_flag/summon {args: {animation: "animation_sway_large", start_animation: true}}
execute align xyz positioned ~0.5 ~0.25 ~0.5 as @n[tag=aj.summit_flag.root, tag=!aj.new, distance=..1] run function summit:flag/init_flag with storage summit:temp summit_flag_macro
