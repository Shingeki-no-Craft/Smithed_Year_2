# @s = @e[type=item_display, tag=summit_flag.changing_height, tag=summit_flag.lowering]
# @s = @e[type=item_display, tag=summit_flag.changing_height, tag=summit_flag.raising]
# at @s
# run by summit:flag/change_height/lower_this
# run by summit:flag/change_height/raise_this

tag @s remove summit_flag.changing_height
tag @s remove summit_flag.lowering
tag @s remove summit_flag.raising
