# this is why it only runs once per 5s
execute as @e[type=minecraft:marker, tag=summit.climbing.climber] at @s run function summit.climbing:climb/check_player_existance/check with entity @s data

# schedule again if summit.climbing players exist
execute if entity @a[tag=summit.climbing.player] run schedule function summit.climbing:climb/check_player_existance/main 5s replace
