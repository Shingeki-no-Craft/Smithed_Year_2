# get from all paths, from id, and position
$data modify entity @s data.tile_data set from storage summit.climbing:paths paths.$(id)."$(pos)"
