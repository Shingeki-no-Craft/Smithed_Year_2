# force ride
function summit.climbing:climb/player/reseat with entity @s

# if player already has tag, do nothing
execute if entity @s[tag=summit.climbing.end] run return 0

# otherwise, start end sequence as climber
$execute at @n[tag=summit.climbing.climber,type=minecraft:marker,distance=..32,nbt={data:{UUID:"$(UUID)"}}] positioned ^ ^-0.7 ^-0.5 run function summit.climbing:climb/player/exit/end_sequence/start
