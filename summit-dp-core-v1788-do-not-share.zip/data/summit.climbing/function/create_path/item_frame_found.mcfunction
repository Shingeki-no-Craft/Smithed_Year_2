# set data
$data modify storage summit.climbing:master init.tile_data.$(direction).$(relation) set value true

# propagate to self
tag @s[tag=!summit.climbing.saved] add summit.climbing.propagated
