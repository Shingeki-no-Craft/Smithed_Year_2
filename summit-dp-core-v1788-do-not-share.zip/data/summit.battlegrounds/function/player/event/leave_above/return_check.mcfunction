
# decrement timer and check if depleted
scoreboard players remove @s summit.battlegrounds.return_timer 1
execute if score @s summit.battlegrounds.return_timer matches 1.. run return 1

# reset timer and untag
scoreboard players reset @s summit.battlegrounds.return_timer
tag @s remove summit.battlegrounds.return

# remove player
function summit.battlegrounds:player/event/leave
