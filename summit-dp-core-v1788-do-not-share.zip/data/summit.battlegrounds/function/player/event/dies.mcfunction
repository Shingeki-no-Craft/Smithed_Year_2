
# reset
scoreboard players reset @s summit.battlegrounds.died

# check if playing
execute if entity @s[tag=!summit.battlegrounds.player] run return 0

# setup player
function summit.battlegrounds:player/action/give_kit
function summit.battlegrounds:player/teleport/random

# function tag
function #summit.battlegrounds:api/player_died
