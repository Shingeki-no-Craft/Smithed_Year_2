
# reset structure
function summit.battlegrounds:api/set_structure {booth_id: "official_summit", structure: "summit.battlegrounds:default"}
$function $(struct_function)

# clear kits
function summit.battlegrounds:utility/clear_kits with storage summit.battlegrounds:database session

# function tag
function #summit.battlegrounds:api/booth_active
