
# notify player
tellraw @s ["", {text: "[Baobab Battlegrounds] ", color: "gold"}, {text: "You have selected this kit!", color: "green"}]

# update the players kit and reset expiration
$data remove storage summit.battlegrounds:database kits[{player_id:$(player_id)}]
data modify storage summit.battlegrounds:database kits append from storage summit.battlegrounds:macro assign_kit
scoreboard players set @s summit.battlegrounds.kit_expiration 180

# $execute store success score #exists summit.battlegrounds run data get storage summit.battlegrounds:database kits[{player_id:$(player_id)}]
# $execute if score #exists summit.battlegrounds matches 1 run data remove storage summit.battlegrounds:database kits[{player_id:$(player_id)}]
