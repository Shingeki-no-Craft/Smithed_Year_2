# @s = summit.node interaction with interaction data
# at undefined
# run from summit.dev:entity/node/tick

execute on target at @s run playsound minecraft:entity.experience_orb.pickup ui @s ~ ~ ~ 1 1
execute unless data entity @s data.ref run data modify entity @s data.ref set value ""
function summit.dev:entity/node/dialog/setup with entity @s data

#// Error message
execute unless score #temp summit.temp matches 67 run function summit.dev:entity/node/dialog/inspectmenu_error with entity @s data

#// Cleanup
scoreboard players reset #temp summit.temp
data remove entity @s interaction
