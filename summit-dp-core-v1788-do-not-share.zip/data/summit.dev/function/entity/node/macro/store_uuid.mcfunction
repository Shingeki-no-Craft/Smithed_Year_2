# @s = @n[type=item_display,tag=new]
# at @n[type=area_effect_cloud,tag=summit.nodeSpawner]
# run from summit.dev:entity/node/init

$data modify storage summit:root dev.nodeList append value {id:$(id),color:$(color),uuid:"$(uuid)"}
