# @s = player via dialog
# at @s
# run from summit.dev:entity/node/dialog/edit_node_coords_confirm

$execute as $(uuid) on passengers run data modify entity @s[type=interaction] data.ref set value "$(newRef)"
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
$execute as $(uuid) on passengers if entity @s[type=interaction] run function summit.dev:entity/node/update_info with entity @s data
