# @s = player via dialog
# at @s
# run from summit.dev:entity/node/dialog/edit_node_coords_pre

$dialog show @s {type:"minecraft:confirmation",title:"Edit Reference Coordinates",body:{type:"minecraft:plain_message",contents:"Edit your node's reference coordinates in the fields below.",width:250},inputs:[{type:"minecraft:text",key:"newRef",width:320,"max_length":500,multiline:{max_lines:4},label:"Paste F3+C Command Here",initial:"/$(ref)"}],can_close_with_escape:true,after_action:"close",yes:{label:"Set Coordinates",action:{type:"minecraft:dynamic/run_command",template:"function summit.dev:entity/node/dialog/edit_node_coords_confirm {id:\"$(id)\",newRef:\"$(newRef)\"}"}},no:{label:"Cancel"}}






