# @s = player who interacted with summit.node interaction
# at @s
# run from summit.dev:entity/node/dialog/edit_node_coords_pre
# run from summit.dev:entity/node/dialog/edit_node_pre

tag @s remove editingNode
tag @s remove deletingNode

tellraw @s {color: "red", text: "[Error] Only the creator of this node may perform this action."}
playsound minecraft:entity.villager.no ui @s
