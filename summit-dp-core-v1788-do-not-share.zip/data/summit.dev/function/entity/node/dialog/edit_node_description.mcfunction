# @s = player who interacted with summit.node interaction
# at @s
# run from summit.dev:entity/node/dialog/edit_node_pre

$dialog show @s {type:"minecraft:confirmation",title:"Edit Node Description",body:{type:"minecraft:plain_message",contents:"Edit your node's description in the text box below.",width:250},inputs:[{type:"minecraft:text",key:"data",label:"New Description",width:320,max_length:728,multiline:{max_lines: 14},initial:"$(text)"}],can_close_with_escape:1,after_action:"close",yes:{label:"Set Description",action:{type:"minecraft:dynamic/run_command",template:"function summit.dev:entity/node/dialog/edit_node_confirm {type:description,id:\"$(id)\",data:\"$(data)\"}"}},no:{label:"Cancel"}}



