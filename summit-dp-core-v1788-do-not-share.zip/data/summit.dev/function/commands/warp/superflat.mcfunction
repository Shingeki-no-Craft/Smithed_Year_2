# run from dialog: summit:development_tools

execute in minecraft:superflat run tp @s 216 39 -125
