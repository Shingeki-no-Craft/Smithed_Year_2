$tp $(x) $(y) $(z)
