execute store result score $min_x summit.temp run data get entity @s Pos[0] 1000
execute store result score $min_y summit.temp run data get entity @s Pos[1] 1000
execute store result score $min_z summit.temp run data get entity @s Pos[2] 1000

scoreboard players operation $max_x summit.temp = $min_x summit.temp
scoreboard players operation $max_y summit.temp = $min_y summit.temp
scoreboard players operation $max_z summit.temp = $min_z summit.temp

execute store result score $spawn_radius summit.temp run data get entity @s data.summit_bird.spawn_radius 1000

scoreboard players operation $min_x summit.temp -= $spawn_radius summit.temp
scoreboard players operation $min_z summit.temp -= $spawn_radius summit.temp

scoreboard players operation $max_x summit.temp += $spawn_radius summit.temp
scoreboard players operation $max_z summit.temp += $spawn_radius summit.temp
scoreboard players add $max_y summit.temp 1000

data modify entity @s data.min set value [0, 0, 0]
data modify entity @s data.max set value [0, 0, 0]

execute store result entity @s data.min[0] double 0.001 run scoreboard players get $min_x summit.temp
execute store result entity @s data.min[1] double 0.001 run scoreboard players get $min_y summit.temp
execute store result entity @s data.min[2] double 0.001 run scoreboard players get $min_z summit.temp

execute store result entity @s data.max[0] double 0.001 run scoreboard players get $max_x summit.temp
execute store result entity @s data.max[1] double 0.001 run scoreboard players get $max_y summit.temp
execute store result entity @s data.max[2] double 0.001 run scoreboard players get $max_z summit.temp
