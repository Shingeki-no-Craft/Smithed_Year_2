# called with parameters:
# model: bird model to use
# variant_count: number of variants this model has
# scare_radius: radius in blocks to check for players in, causing birds to scatter when a player is in range
# spawn_radius: radius in blocks to spawn birds in
# max_birds: maximum number of birds to spawn
# ambient_sound: ambient sound to play for birds
# ambient_sound_chance: the percentage chance to play a bird's ambient sound every quarter second (there's a 20% chance of the event triggering) (1-100%)
# fly_sound: sound to play when birds fly away
# scare_sound: sound to play when birds get scared
# bird_chance: the percentage chance to spawn a bird every quarter second (1-100%)

$data modify storage summit:temp bird_spawner.data set value {name:"Bird Spawner",summit_bird:{model:"$(model)",variant_count:$(variant_count),scare_radius:$(scare_radius),spawn_radius:$(spawn_radius),ambient_sound:"$(ambient_sound)",ambient_sound_chance:$(ambient_sound_chance),fly_sound:"$(fly_sound)",scare_sound:"$(scare_sound)",max_birds:$(max_birds),bird_chance:$(bird_chance)}}
execute align xyz positioned ~0.5 ~ ~0.5 summon minecraft:marker run function summit.birds:spawner/setup
