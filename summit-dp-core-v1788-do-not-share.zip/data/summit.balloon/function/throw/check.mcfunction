execute if items entity @s contents minecraft:bundle[minecraft:custom_data~{summit: {balloon: {}}}] run function summit.balloon:throw/float
