# get data
item replace block -30000000 0 0 container.0 from entity @s inventory.25

# set slot
data modify storage summit:temp balloon.slot set value "inventory.25"

# do checks and process
function summit.balloon:inventory/process
