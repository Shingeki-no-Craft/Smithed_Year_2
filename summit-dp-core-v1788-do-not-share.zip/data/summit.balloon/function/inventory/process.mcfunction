# get the data
data modify storage summit:temp balloon.item set from block -30000000 0 0 Items[{Slot: 0b}]
data modify storage summit:temp balloon.item.slot set from storage summit:temp balloon.slot

# get amount of contents
scoreboard players set $count summit.temp 0
execute store result score $count summit.temp run data get storage summit:temp balloon.item.components."minecraft:bundle_contents"

# compare previous bundle contents amount to current bundle contents amount, if match then do nothing
execute store result score $old_count summit.temp run data get storage summit:temp balloon.item.components."minecraft:custom_data".summit.balloon.count
execute if score $old_count summit.temp = $count summit.temp run return fail

# get last item
data modify storage summit:temp balloon.last_item set from storage summit:temp balloon.item.components."minecraft:bundle_contents"[0]

# if last added item is not a balloon, remove
execute unless data storage summit:temp balloon.last_item{components: {"minecraft:custom_data": {summit: {balloon: {}}}}} run return run function summit.balloon:inventory/remove/main

# if bundle and only one item, unbundle
execute if score $count summit.temp matches 1 if data storage summit:temp balloon.item.components."minecraft:custom_data".summit.balloon.bundle run return run function summit.balloon:inventory/unbundle

# update data based on bundle contents
function summit.balloon:update

# modify item using updated data
function summit.balloon:inventory/modify with storage summit:temp balloon.item
