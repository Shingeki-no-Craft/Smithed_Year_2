data modify storage summit:temp balloon.item set from storage summit:temp balloon.item.components."minecraft:bundle_contents"[0]
data modify storage summit:temp balloon.item.slot set from storage summit:temp balloon.slot

# have to set the bundle contents to nothing otherwise it doesn't take
data modify storage summit:temp balloon.item.components."minecraft:bundle_contents" set value []

# modify item using updated data
function summit.balloon:inventory/modify with storage summit:temp balloon.item
