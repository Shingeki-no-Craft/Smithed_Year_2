$loot give @s loot { pools: [ { rolls: 1, entries: [{type:"minecraft:loot_table",value:"summit.balloon:technical/balloon"}] } ], functions: [ {function:"minecraft:set_name", "target":"item_name", "name":"$(name)"}, {function:"minecraft:set_custom_data", tag:{"summit":{"balloon":{"stamp":"$(stamp)"}}}}, {function:"minecraft:set_custom_model_data", floats:{mode:"replace_all",values:[1]}, strings:{mode:"replace_all",values:["$(model)"]}} ] }











