kill @e[tag=snc.colossal_head]
