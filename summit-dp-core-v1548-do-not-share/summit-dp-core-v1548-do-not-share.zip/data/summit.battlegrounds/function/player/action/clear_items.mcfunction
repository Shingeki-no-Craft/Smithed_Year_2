clear @s *
