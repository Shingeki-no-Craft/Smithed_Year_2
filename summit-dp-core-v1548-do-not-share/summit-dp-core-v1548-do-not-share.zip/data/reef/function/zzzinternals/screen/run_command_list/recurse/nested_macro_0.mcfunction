$$(current_command)
